//Author: Andy Davis
//Date: 10/15/2020
//Assignment: Bulgarian Solitaire Assignment
//Class: Java CIS 016

package BulgarianSolitaireAssignmentPackage;

/* Import libraries */
//import java.util.*;

public class SolitaireGame {

	public static void main(String[] args) {
		//Initialize new game
		BulgarianSolitaire game = new BulgarianSolitaire();
		
		
		//Play the game
		game.play();
	}

}
